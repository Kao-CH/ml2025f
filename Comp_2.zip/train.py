from ultralytics import YOLO
#模型參數參考網址:https://github.com/ultralytics/ultralytics/blob/main/ultralytics/cfg/default.yaml
def main():
    
    model = YOLO('yolo12n.pt') #初次訓練使用YOLO官方的預訓練模型，如要使用自己的模型訓練可以將'yolo12n.pt'替換掉
    results = model.train(data="./aortic_valve.yaml",
                epochs=50, #跑幾個epoch
                imgsz=640, #圖片大小640*640
                batch=2, #batch_size
                device=0, #使用哪一個GPU，0代表第一個GPU
                )
    
if __name__ == "__main__":
    import multiprocessing as mp
    mp.freeze_support()
    main()